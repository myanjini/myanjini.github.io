import { useCallback, useState } from 'react';
import { listBooks } from '../api/books';
import { checkHealth } from '../api/health';
import { usePolling } from '../hooks/usePolling';
import HealthPanel from './HealthPanel';
import KpiCard from './KpiCard';
import LogAnalyzer from './LogAnalyzer';
import StatusBadge from './StatusBadge';
import StatusDistribution from './StatusDistribution';
import { average, errorRate, healthLevel, percentile } from './metrics';
import { useTelemetry } from './useTelemetry';

const HEALTH_INTERVAL_MS = 10_000;
const KPI_INTERVAL_MS = 60_000;
const HISTORY_SIZE = 30;

const clock = new Intl.DateTimeFormat('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

export default function DashboardPage() {
  const [history, setHistory] = useState([]);
  const [bookTotal, setBookTotal] = useState(null);
  const records = useTelemetry();

  const pollHealth = useCallback(async (signal) => {
    const result = await checkHealth(signal);
    setHistory((prev) => [...prev, result].slice(-HISTORY_SIZE));
  }, []);

  // limit=1로 요청하면 목록 대신 total 값만 가볍게 얻을 수 있습니다.
  const pollKpi = useCallback(async (signal) => {
    const page = await listBooks({ limit: 1 }, signal);
    setBookTotal(page.total);
  }, []);

  usePolling(pollHealth, HEALTH_INTERVAL_MS);
  usePolling(pollKpi, KPI_INTERVAL_MS);

  const latest = history.at(-1);
  const level = healthLevel(latest);
  const durations = records.map((r) => r.durationMs);
  const rate = errorRate(records);

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>도서 서비스 관제 대시보드</h1>
        <p className="muted">
          헬스 체크 {HEALTH_INTERVAL_MS / 1000}초 간격, 마지막 갱신{' '}
          {latest ? clock.format(latest.checkedAt) : '-'}
        </p>
      </header>

      <div className="kpi-row">
        <KpiCard title="API 상태" hint={latest ? `HTTP ${latest.httpStatus || '응답 없음'}` : null}>
          <StatusBadge level={level} />
        </KpiCard>
        <KpiCard title="데이터베이스" hint={latest?.database}>
          <StatusBadge level={latest ? (latest.database === 'ok' ? 'good' : 'critical') : 'unknown'} />
        </KpiCard>
        <KpiCard title="등록 도서" value={bookTotal === null ? null : bookTotal.toLocaleString('ko-KR')} unit="권" />
        <KpiCard
          title="브라우저 측정 응답 시간"
          value={average(durations)}
          unit="ms"
          hint={`p95 ${percentile(durations, 95) ?? '-'} ms, 최근 ${records.length}건`}
        />
        <KpiCard
          title="오류율 (5xx, 연결 실패)"
          value={rate === null ? null : rate.toFixed(1)}
          unit="%"
          hint="이 브라우저에서 보낸 요청 기준"
        />
      </div>

      <div className="grid-2">
        <HealthPanel history={history} />
        <StatusDistribution records={records} title="브라우저 요청 상태 코드 분포" />
      </div>

      <LogAnalyzer />
    </div>
  );
}
