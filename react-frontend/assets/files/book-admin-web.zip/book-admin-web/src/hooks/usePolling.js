import { useEffect, useRef } from 'react';

// intervalMs마다 task를 실행합니다. 탭이 보이지 않을 때는 쉬고,
// 앞선 작업이 끝나기 전에는 다음 작업을 시작하지 않습니다.
export function usePolling(task, intervalMs, enabled = true) {
  // 최신 task를 ref에 담아 두면 task가 바뀌어도 타이머를 다시 만들지 않습니다.
  const taskRef = useRef(task);
  useEffect(() => {
    taskRef.current = task;
  }, [task]);

  useEffect(() => {
    if (!enabled) return;
    let timer;
    let stopped = false;
    const controller = new AbortController();

    async function tick() {
      if (document.visibilityState === 'visible') {
        try {
          await taskRef.current(controller.signal);
        } catch (error) {
          if (error.name !== 'AbortError' && error.name !== 'CanceledError') console.error(error);
        }
      }
      if (!stopped) timer = setTimeout(tick, intervalMs);
    }

    tick();
    return () => {
      stopped = true;
      clearTimeout(timer);
      controller.abort();
    };
  }, [intervalMs, enabled]);
}
