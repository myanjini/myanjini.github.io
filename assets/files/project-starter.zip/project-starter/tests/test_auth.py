def test_signup_does_not_return_password(client):
    response = client.post("/auth/signup", json={"email": "new@example.com", "password": "test-pass-123"})
    assert response.status_code == 201
    body = response.json()
    assert body["email"] == "new@example.com"
    assert "password" not in body and "hashed_password" not in body


def test_signup_with_duplicate_email_returns_409(client):
    client.post("/auth/signup", json={"email": "dup@example.com", "password": "test-pass-123"})
    response = client.post("/auth/signup", json={"email": "DUP@example.com", "password": "test-pass-123"})
    assert response.status_code == 409


def test_login_with_wrong_password_returns_401(client, make_user):
    make_user("user1@example.com")
    response = client.post("/auth/token", data={"username": "user1@example.com", "password": "wrong-pass"})
    assert response.status_code == 401
    assert response.json()["code"] == "INVALID_CREDENTIALS"


def test_me_with_token(client, auth_headers):
    response = client.get("/auth/me", headers=auth_headers)
    assert response.status_code == 200
    assert response.json()["email"] == "tester@example.com"


def test_refresh_token_can_be_used_only_once(client, make_user):
    make_user("user1@example.com")
    tokens = client.post("/auth/token", data={"username": "user1@example.com", "password": "test-pass-123"}).json()

    first = client.post("/auth/refresh", json={"refresh_token": tokens["refresh_token"]})
    assert first.status_code == 200
    assert first.json()["refresh_token"] != tokens["refresh_token"]

    second = client.post("/auth/refresh", json={"refresh_token": tokens["refresh_token"]})
    assert second.status_code == 401


def test_logout_blocks_refresh(client, make_user):
    make_user("user1@example.com")
    tokens = client.post("/auth/token", data={"username": "user1@example.com", "password": "test-pass-123"}).json()
    assert client.post("/auth/logout", json={"refresh_token": tokens["refresh_token"]}).status_code == 204
    response = client.post("/auth/refresh", json={"refresh_token": tokens["refresh_token"]})
    assert response.status_code == 401


def test_login_is_locked_after_five_failures(client, make_user):
    make_user("user1@example.com")
    for _ in range(5):
        client.post("/auth/token", data={"username": "user1@example.com", "password": "wrong-pass"})
    # 여섯 번째는 비밀번호가 맞아도 막힙니다.
    response = client.post("/auth/token", data={"username": "user1@example.com", "password": "test-pass-123"})
    assert response.status_code == 429


def test_health(client):
    assert client.get("/health").json() == {"status": "ok", "database": "ok"}
