# 미니 프로젝트 시작 템플릿

도서 API에서 주제와 상관없이 다시 쓸 수 있는 부분만 남긴 템플릿입니다. 회원가입과 로그인, 오류 응답, 로그, 설정, 컨테이너, 테스트와 배포 워크플로가 이미 들어 있으므로, 내 주제의 모델과 API만 더하면 됩니다.

## 들어 있는 것

| 위치 | 내용 | 고칠 일 |
|---|---|---|
| app/config.py | 환경 변수 설정, Parameter Store 읽기 | 앱 이름 |
| app/database.py | 엔진, 세션, Base | 없음 |
| app/models.py | User, RefreshToken, LoginFailure | 주 자원 모델 추가 |
| app/schemas.py | 회원가입, 토큰, InputModel | 입력 모델과 응답 모델 추가 |
| app/dependencies.py | SessionDep, CurrentUserDep, require_admin, PageDep | 필요하면 의존성 추가 |
| app/routers/auth.py | 회원가입, 로그인, 내 정보, 재발급, 로그아웃 | 없음 |
| app/services/login_guard.py | 로그인 실패 제한(계정 5회, IP 20회, 15분) | 없음 |
| app/main.py | 요청 로그, 보안 헤더, 오류 처리, /health | 내 라우터 등록 |
| app/logging_config.py, app/privacy.py | JSON 로그, 이메일과 토큰 가리기 | 없음 |
| tests/ | 테스트용 DB, make_user 픽스처, 인증 테스트 8개 | 내 테스트 추가 |
| migrations/ | Alembic 설정(리비전 없음) | 첫 리비전 만들기 |
| Dockerfile, compose.yaml | 로컬 컨테이너 실행 | 없음 |
| compose.prod.yaml, .github/workflows/ | 운영 배포(S18-P61에서 사용) | 없음 |

`TODO`로 표시한 곳이 내가 채울 곳입니다.

```bash
grep -rn "TODO" app
```

## 처음 실행

```bash
python -m venv .venv
source .venv/bin/activate          # Windows는 .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # SECRET_KEY를 새로 만들어 채웁니다.
pytest                             # 인증 테스트 8개가 통과해야 합니다.
```

모델을 추가한 뒤 첫 리비전을 만들고 적용합니다.

```bash
alembic revision --autogenerate -m "create tables"
alembic upgrade head
uvicorn app.main:app --reload
```

## 내 프로젝트 README에 적을 것

이 파일은 템플릿 안내입니다. 제출할 때는 아래 항목으로 다시 씁니다(S18-P61).

1. 프로젝트 소개(한 문장)
2. 실행 방법
3. API 목록(명세서 링크)
4. 보안 조치 요약
5. 배포 주소와 확인 방법
