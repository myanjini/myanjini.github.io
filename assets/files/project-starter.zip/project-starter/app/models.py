from datetime import datetime

from sqlalchemy import ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True)
    # 비밀번호 원문이 아니라 해시만 저장합니다.
    hashed_password: Mapped[str] = mapped_column(String(255))
    # 역할: 일반 사용자는 "user", 관리자는 "admin"
    role: Mapped[str] = mapped_column(String(20), default="user")


class RefreshToken(Base):
    __tablename__ = "refresh_tokens"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    # 토큰 원문이 아니라 SHA-256 해시(64글자)를 저장합니다.
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    expires_at: Mapped[datetime]  # 만료 시각(UTC)
    revoked: Mapped[bool] = mapped_column(default=False)  # True면 더는 쓸 수 없는 토큰


class LoginFailure(Base):
    """로그인 실패 기록. 일정 시간 안의 실패 횟수를 세는 데 씁니다."""

    __tablename__ = "login_failures"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), index=True)
    ip: Mapped[str] = mapped_column(String(45), index=True)  # IPv6 주소까지 담을 수 있는 길이
    created_at: Mapped[datetime] = mapped_column(index=True)


# TODO(S17-P58-02): 이 아래에 내 프로젝트의 주 자원 모델을 추가합니다.
