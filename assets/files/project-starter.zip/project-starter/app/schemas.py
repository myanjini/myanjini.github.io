from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_serializer, model_validator

from app.privacy import mask_email


class InputModel(BaseModel):
    """요청 본문 모델의 공통 부모. 정의하지 않은 필드가 오면 422로 거절합니다."""

    model_config = ConfigDict(extra="forbid")


# 실제 서비스에서는 유출된 비밀번호 목록 수십만 개를 씁니다. 여기서는 예시로 몇 개만 둡니다.
COMMON_PASSWORDS = {
    "password1234", "1234567890", "qwerty1234", "qwertyuiop", "iloveyou12",
    "admin12345", "abcd123456", "1q2w3e4r5t", "password12", "welcome123",
}


class UserCreate(InputModel):
    """회원가입에 쓰는 입력 모델"""
    email: EmailStr = Field(examples=["user1@example.com"])
    password: str = Field(min_length=10, max_length=64, examples=["practice-pass-1"])

    @model_validator(mode="after")
    def check_password_rules(self):
        password = self.password.lower()
        email_id = self.email.split("@")[0].lower()
        if password in COMMON_PASSWORDS:
            raise ValueError("너무 흔한 비밀번호입니다.")
        if len(email_id) >= 3 and email_id in password:
            raise ValueError("비밀번호에 이메일 아이디를 넣을 수 없습니다.")
        if len(set(password)) < 4:
            raise ValueError("같은 글자를 반복한 비밀번호는 쓸 수 없습니다.")
        return self


class UserRead(BaseModel):
    """사용자 응답 모델. 비밀번호 해시는 넣지 않습니다."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    email: str
    role: str


class UserSummary(UserRead):
    """목록 화면용 사용자 정보. 이메일은 일부만 보여 줍니다."""

    @field_serializer("email")
    def mask_email_field(self, email: str) -> str:
        return mask_email(email)


class Token(BaseModel):
    """로그인과 재발급 응답. 두 토큰을 함께 돌려줍니다."""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshRequest(InputModel):
    """재발급과 로그아웃 요청 본문"""
    refresh_token: str = Field(min_length=1)


# TODO(S17-P58-02): 이 아래에 내 프로젝트의 입력 모델과 응답 모델을 추가합니다.
# 입력 모델은 InputModel을 상속해, 정의하지 않은 필드(owner_id 같은 값)를 422로 거절합니다.
