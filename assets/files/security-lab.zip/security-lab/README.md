# 진단용 예제 API: 동아리 공지 게시판

S11-P38과 S11-P39 실습에서 쓰는 예제입니다. `app.py`에는 보안약점이 일부러 섞여 있습니다.

- 실습 컴퓨터에서만 실행하고, 인터넷에 공개하지 않습니다.
- 도서 API 프로젝트와 다른 폴더에서 작업합니다.

## 폴더 구성

| 파일 | 내용 |
|---|---|
| app.py | 진단할 코드(FastAPI와 sqlite3로 만든 한 파일짜리 API) |
| requirements.txt | 필요한 패키지 |
| tests/test_security.py | 보안 테스트. 조치 전에는 실패하고, 조치를 마치면 통과해야 합니다. |
| tests/conftest.py | 테스트 준비 코드 |

## 준비

```
python -m venv .venv
(macOS, Linux) source .venv/bin/activate
(Windows) .venv\Scripts\activate
pip install -r requirements.txt
```

## 실행

```
uvicorn app:app --reload
```

http://127.0.0.1:8000/docs 에서 API를 확인합니다.

## 보안 테스트

```
pytest -q
```

Windows에서는 명령어 삽입 테스트(test_03)가 macOS나 Linux와 다르게 동작할 수 있습니다. 그럴 때는 S8에서 쓴 Docker로 리눅스 환경에서 테스트를 실행합니다.

```
docker run --rm -v "${PWD}:/lab" -w /lab python:3.12-slim sh -c "pip install -q -r requirements.txt && pytest -q -p no:cacheprovider"
```
