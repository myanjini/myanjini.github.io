"""보안 테스트: 진단표의 보안약점이 조치되었는지 확인합니다.

진단용 예제(조치 전)에서는 대부분 실패하고, 조치를 마치면 모두 통과해야 합니다.
테스트 이름 앞의 번호는 예시 진단표의 번호입니다.
"""
import base64
import hashlib
import os
import pickle
import random
import sqlite3
import threading
from pathlib import Path

import requests


def run_together(func, count):
    """func를 count개의 스레드에서 동시에 실행하고 결과 목록을 돌려줍니다."""
    results = [None] * count
    start = threading.Barrier(count)

    def worker(i):
        start.wait()  # 모든 스레드가 준비될 때까지 기다렸다가 한꺼번에 출발합니다.
        results[i] = func(i)

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(count)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=10)
    return results


# ---------- 입력데이터 검증 및 표현 ----------
def test_01_search_sql_injection(client, login, notice):
    payload = "%' UNION SELECT id, username, password_hash FROM users --"
    res = client.get("/notices", params={"q": payload})
    assert res.status_code == 200
    assert all(item["title"] != "alice" for item in res.json())  # 사용자 정보가 섞여 나오면 안 됩니다.


def test_01_sort_must_be_allowed_value(client):
    res = client.get("/notices", params={"sort": "(SELECT password_hash FROM users)"})
    assert res.status_code == 422


def test_02_download_path_traversal(client):
    res = client.get("/files/%2e%2e%2fboard.db")  # ../board.db
    assert res.status_code == 404
    assert b"SQLite" not in res.content


def test_02_upload_filename_cannot_escape(client, login):
    headers = login("alice")
    client.post("/files", files={"file": ("../escape.txt", b"hello")}, headers=headers)
    assert not Path("escape.txt").exists()  # 업로드 폴더 밖(임시 폴더)에 파일이 생기면 안 됩니다.


def test_03_command_injection(client, login):
    headers = login("alice")
    client.post("/files", files={"file": ("memo.txt;touch injected", b"hello")}, headers=headers)
    assert not Path("injected").exists()


def test_04_dangerous_extension_rejected(client, login):
    headers = login("alice")
    res = client.post("/files", files={"file": ("shell.py", b"import os")}, headers=headers)
    assert res.status_code == 400


def test_05_ssrf_internal_address_blocked(client, login, monkeypatch):
    called = []
    monkeypatch.setattr(requests, "get", lambda url, **kw: called.append(url))  # 실제로 요청하지 않습니다.
    headers = login("alice")
    res = client.get("/link-preview", params={"url": "http://169.254.169.254/latest/meta-data/"}, headers=headers)
    assert res.status_code == 400
    assert called == []


def test_06_role_header_is_not_trusted(client, login, notice):
    headers = login("bob")
    res = client.post(f"/admin/notices/{notice}/pin", headers={**headers, "X-Role": "admin"})
    assert res.status_code == 403


# ---------- 보안기능 ----------
def test_07_cannot_delete_others_notice(client, login, notice):
    headers = login("bob")
    res = client.delete(f"/notices/{notice}", headers=headers)
    assert res.status_code == 404
    assert client.get(f"/notices/{notice}").status_code == 200  # 공지가 그대로 남아 있어야 합니다.


def test_08_password_not_stored_as_md5(client):
    client.post("/signup", json={"username": "alice", "password": "club-pass-1234"})
    stored = sqlite3.connect("board.db").execute("SELECT password_hash FROM users").fetchone()[0]
    assert stored != hashlib.md5(b"club-pass-1234").hexdigest()
    assert stored.startswith("$argon2")


def test_09_weak_password_rejected(client):
    res = client.post("/signup", json={"username": "alice", "password": "1234"})
    assert res.status_code == 422


def test_10_login_attempts_limited(client, login):
    login("alice")
    codes = [client.post("/login", json={"username": "alice", "password": "wrong-pass-00"}).status_code
             for _ in range(6)]
    assert codes[:5] == [401] * 5
    assert codes[5] == 429


def test_11_secret_key_not_in_code(board):
    source = Path(board.__file__).read_text(encoding="utf-8")
    assert "club-board-secret" not in source


def test_12_reset_code_not_predictable(client, board):
    random.seed(2026)
    client.post("/password-reset", params={"username": "alice"})
    predicted = str(random.Random(2026).randint(100000, 999999))  # 같은 시드면 같은 수가 나옵니다.
    row = sqlite3.connect("board.db").execute("SELECT * FROM reset_codes").fetchone()
    assert predicted not in row
    assert hashlib.sha256(predicted.encode()).hexdigest() not in row


def test_13_import_requires_admin(client, login):
    headers = login("bob")
    res = client.post("/notices/import", content="- {title: 광고, body: 광고}", headers=headers)
    assert res.status_code == 403


# ---------- 시간 및 상태 ----------
def test_14_concurrent_likes_all_counted(client, notice):
    run_together(lambda i: client.post(f"/notices/{notice}/like"), 10)
    assert client.get(f"/notices/{notice}").json()["likes"] == 10


def test_15_retry_has_limit(client, login, monkeypatch):
    calls = []

    def always_fail(url, **kw):
        calls.append(url)
        if len(calls) > 20:  # 끝없이 반복하는 코드라도 테스트는 멈추게 합니다.
            raise RuntimeError("반복이 끝나지 않습니다.")
        raise requests.ConnectionError("연결 실패")

    monkeypatch.setattr(requests, "get", always_fail)
    monkeypatch.setattr("time.sleep", lambda s: None)
    headers = login("alice")
    client.get("/link-preview", params={"url": "https://example.com/"}, headers=headers)
    assert len(calls) <= 3


# ---------- 에러처리 ----------
def test_16_error_response_hides_details(client):
    res = client.get("/notices/9999")
    assert "Traceback" not in res.text
    assert "trace" not in res.json()


# ---------- 코드오류 ----------
def test_18_missing_notice_is_404(client):
    assert client.get("/notices/9999").status_code == 404


class Evil:
    def __reduce__(self):
        return (os.mkdir, ("pickle_ran",))  # 토큰을 읽는 순간 서버에서 실행될 코드


def test_20_token_is_not_deserialized(client):
    forged = base64.b64encode(pickle.dumps(Evil())).decode()
    res = client.get("/me", headers={"Authorization": f"Bearer {forged}"})
    assert not Path("pickle_ran").exists()
    assert res.status_code == 401


def test_20_forged_admin_token_rejected(client):
    forged = base64.b64encode(pickle.dumps({"id": 1, "username": "hacker", "role": "admin"})).decode()
    res = client.get("/me", headers={"Authorization": f"Bearer {forged}"})
    assert res.status_code == 401


# ---------- 캡슐화 ----------
def test_21_signup_response_has_no_hash(client):
    res = client.post("/signup", json={"username": "alice", "password": "club-pass-1234"})
    assert "password_hash" not in res.json()


def test_22_me_is_not_mixed_between_users(client, login):
    users = [f"user{i}" for i in range(5)]
    headers = [login(name) for name in users]
    names = run_together(lambda i: client.get("/me", headers=headers[i]).json()["username"], 5)
    assert names == users  # 각자 자기 이름을 받아야 합니다.


def test_23_debug_endpoint_removed(client):
    assert client.get("/debug/config").status_code == 404


def test_23_password_not_printed(client, capsys):
    client.post("/signup", json={"username": "alice", "password": "club-pass-1234"})
    client.post("/login", json={"username": "alice", "password": "club-pass-1234"})
    assert "club-pass-1234" not in capsys.readouterr().out


# ---------- API 오용 ----------
def test_24_yaml_cannot_create_objects(client, admin_headers):
    body = '- !!python/object/apply:os.mkdir ["yaml_ran"]'
    client.post("/notices/import", content=body, headers=admin_headers)
    assert not Path("yaml_ran").exists()
