"""모임 서비스: 규칙과 권한 검사를 둡니다."""
import logging

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.errors import AppError
from app.models import Membership, Study, User
from app.repositories import studies as study_repo
from app.schemas import StudyCreate, StudyUpdate

PAGE_SIZE = 10  # 목록 한 페이지에 보여 줄 모임 수
logger = logging.getLogger(__name__)


def find_study(db: Session, study_id: int) -> Study:
    study = study_repo.get(db, study_id)
    if study is None:
        raise AppError(404, "STUDY_NOT_FOUND", f"{study_id}번 모임을 찾을 수 없습니다.")
    return study


def create_study(db: Session, user: User, study_in: StudyCreate) -> Study:
    study = study_repo.add(db, Study(**study_in.model_dump(), owner_id=user.id))
    db.add(Membership(study_id=study.id, user_id=user.id))  # 개설자는 첫 참가자입니다.
    db.commit()
    db.refresh(study)
    logger.info("모임 등록", extra={"user_id": user.id, "study_id": study.id})
    return study


def list_studies(db: Session, keyword: str | None, page: int) -> dict:
    items, total = study_repo.search(db, keyword, (page - 1) * PAGE_SIZE, PAGE_SIZE)
    return {"items": items, "total": total, "page": page, "size": PAGE_SIZE}


def update_study(db: Session, user: User, study_id: int, study_in: StudyUpdate) -> Study:
    study = find_study(db, study_id)
    check_can_modify(study, user)
    changes = study_in.model_dump(exclude_unset=True)  # 보낸 항목만 바꿉니다.
    if changes.get("capacity") is not None and changes["capacity"] < study.member_count:
        raise AppError(409, "CAPACITY_TOO_SMALL", f"정원을 지금 인원({study.member_count}명)보다 적게 줄일 수 없습니다.")
    for key, value in changes.items():
        if value is not None:  # null로 보낸 항목은 바꾸지 않습니다.
            setattr(study, key, value)
    db.commit()
    db.refresh(study)
    return study


def delete_study(db: Session, user: User, study_id: int) -> None:
    study = find_study(db, study_id)
    check_can_modify(study, user)
    study_repo.delete(db, study)
    db.commit()
    logger.info("모임 삭제", extra={"user_id": user.id, "study_id": study_id})


def check_can_modify(study: Study, user: User) -> None:
    """개설자나 관리자만 모임을 수정, 삭제하고 명단을 볼 수 있습니다."""
    if user.role == "admin" or study.owner_id == user.id:
        return
    raise AppError(403, "FORBIDDEN", "모임을 개설한 사람만 할 수 있습니다.")


def join_study(db: Session, user: User, study_id: int) -> Study:
    study = find_study(db, study_id)
    if study_repo.find_membership(db, study.id, user.id) is not None:
        raise AppError(409, "ALREADY_JOINED", "이미 참가한 모임입니다.")
    # 모집 중이고 자리가 남았을 때만 인원이 늘어납니다. 동시에 마지막 자리를 노려도 한 명만 성공합니다.
    if not study_repo.increase_member_count(db, study.id):
        db.refresh(study)
        reason = "모집이 마감된 모임입니다." if not study.is_open else "정원이 모두 찼습니다."
        raise AppError(409, "CANNOT_JOIN", reason)
    try:
        study_repo.add_membership(db, study.id, user.id)
    except IntegrityError:  # 같은 사람의 동시 요청이 먼저 참가를 기록한 경우
        db.rollback()
        raise AppError(409, "ALREADY_JOINED", "이미 참가한 모임입니다.")
    db.commit()
    db.refresh(study)
    logger.info("모임 참가", extra={"user_id": user.id, "study_id": study.id})
    return study


def leave_study(db: Session, user: User, study_id: int) -> None:
    study = find_study(db, study_id)
    if study.owner_id == user.id:
        raise AppError(409, "OWNER_CANNOT_LEAVE", "개설자는 나갈 수 없습니다. 모임을 삭제하세요.")
    membership = study_repo.find_membership(db, study.id, user.id)
    if membership is None:
        raise AppError(404, "NOT_A_MEMBER", "참가하지 않은 모임입니다.")
    db.delete(membership)
    study_repo.decrease_member_count(db, study.id)
    db.commit()


def list_members(db: Session, user: User, study_id: int) -> list[dict]:
    study = find_study(db, study_id)
    check_can_modify(study, user)  # 명단은 개설자와 관리자만 봅니다.
    return [{"user_id": m.user_id, "email": m.user.email, "joined_at": m.joined_at}
            for m in study_repo.list_members(db, study.id)]


def joined_studies(db: Session, user: User) -> list[Study]:
    return study_repo.list_joined(db, user.id)
