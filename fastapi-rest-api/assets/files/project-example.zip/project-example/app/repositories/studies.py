"""모임 저장소: 데이터베이스에서 모임과 참가 기록을 읽고 쓰는 코드만 둡니다. commit은 하지 않습니다."""
from sqlalchemy import func, select, update
from sqlalchemy.orm import Session, selectinload

from app.models import Membership, Study


def get(db: Session, study_id: int) -> Study | None:
    return db.get(Study, study_id)


def search(db: Session, keyword: str | None, offset: int, limit: int) -> tuple[list[Study], int]:
    """제목에 keyword가 들어간 모임 한 페이지와 전체 개수를 돌려줍니다."""
    conditions = [Study.title.contains(keyword)] if keyword else []
    total = db.scalar(select(func.count()).select_from(Study).where(*conditions))
    stmt = select(Study).where(*conditions).order_by(Study.id.desc()).offset(offset).limit(limit)
    return list(db.scalars(stmt).all()), total


def add(db: Session, study: Study) -> Study:
    db.add(study)
    db.flush()  # INSERT를 먼저 실행해 study.id를 받습니다.
    return study


def delete(db: Session, study: Study) -> None:
    db.delete(study)


def find_membership(db: Session, study_id: int, user_id: int) -> Membership | None:
    return db.scalar(select(Membership).where(Membership.study_id == study_id, Membership.user_id == user_id))


def add_membership(db: Session, study_id: int, user_id: int) -> None:
    db.add(Membership(study_id=study_id, user_id=user_id))
    db.flush()  # 같은 사람이 두 번 참가하면 여기서 IntegrityError가 납니다.


def increase_member_count(db: Session, study_id: int) -> bool:
    """모집 중이고 자리가 남았을 때만 인원을 1 늘립니다. 늘렸으면 True를 돌려줍니다."""
    stmt = (
        update(Study)
        .where(Study.id == study_id, Study.is_open.is_(True), Study.member_count < Study.capacity)
        .values(member_count=Study.member_count + 1)  # 지금 값에 더하는 계산을 데이터베이스가 합니다.
        .execution_options(synchronize_session=False)
    )
    return db.execute(stmt).rowcount == 1


def decrease_member_count(db: Session, study_id: int) -> None:
    stmt = (update(Study).where(Study.id == study_id)
            .values(member_count=Study.member_count - 1).execution_options(synchronize_session=False))
    db.execute(stmt)


def list_members(db: Session, study_id: int) -> list[Membership]:
    stmt = (select(Membership).options(selectinload(Membership.user))
            .where(Membership.study_id == study_id).order_by(Membership.id))
    return list(db.scalars(stmt).all())


def list_joined(db: Session, user_id: int) -> list[Study]:
    """이 사용자가 참가한(개설한 모임 포함) 모임 목록"""
    stmt = (select(Study).join(Membership).where(Membership.user_id == user_id)
            .order_by(Membership.id.desc()))
    return list(db.scalars(stmt).all())
