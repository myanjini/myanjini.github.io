from datetime import datetime

from sqlalchemy import ForeignKey, String, UniqueConstraint, func, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True)
    # 비밀번호 원문이 아니라 해시만 저장합니다.
    hashed_password: Mapped[str] = mapped_column(String(255))
    # 역할: 일반 사용자는 "user", 관리자는 "admin"
    role: Mapped[str] = mapped_column(String(20), default="user")


class RefreshToken(Base):
    __tablename__ = "refresh_tokens"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    # 토큰 원문이 아니라 SHA-256 해시(64글자)를 저장합니다.
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    expires_at: Mapped[datetime]  # 만료 시각(UTC)
    revoked: Mapped[bool] = mapped_column(default=False)  # True면 더는 쓸 수 없는 토큰


class LoginFailure(Base):
    """로그인 실패 기록. 일정 시간 안의 실패 횟수를 세는 데 씁니다."""

    __tablename__ = "login_failures"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), index=True)
    ip: Mapped[str] = mapped_column(String(45), index=True)  # IPv6 주소까지 담을 수 있는 길이
    created_at: Mapped[datetime] = mapped_column(index=True)



class Study(Base):
    """스터디 모임"""

    __tablename__ = "studies"

    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(String(1000), default="")
    capacity: Mapped[int]  # 정원(개설자 포함)
    member_count: Mapped[int] = mapped_column(default=1, server_default="1")  # 지금 참가 인원(개설자 포함)
    is_open: Mapped[bool] = mapped_column(default=True, server_default=text("true"))  # 모집 중이면 True
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id"))  # 개설자
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())

    # 이 모임의 참가 기록. 모임을 지우면 참가 기록도 함께 지웁니다.
    memberships: Mapped[list["Membership"]] = relationship(back_populates="study", cascade="all, delete-orphan")


class Membership(Base):
    """누가 어떤 모임에 참가했는지 기록합니다."""

    __tablename__ = "memberships"
    # 한 사람은 한 모임에 한 번만 참가할 수 있게 데이터베이스가 막습니다.
    __table_args__ = (UniqueConstraint("study_id", "user_id", name="uq_memberships_study_user"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    study_id: Mapped[int] = mapped_column(ForeignKey("studies.id"))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    joined_at: Mapped[datetime] = mapped_column(server_default=func.now())

    study: Mapped["Study"] = relationship(back_populates="memberships")
    user: Mapped["User"] = relationship()
