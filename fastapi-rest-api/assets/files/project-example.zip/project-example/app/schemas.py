from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_serializer, model_validator

from app.privacy import mask_email


class InputModel(BaseModel):
    """요청 본문 모델의 공통 부모. 정의하지 않은 필드가 오면 422로 거절합니다."""

    model_config = ConfigDict(extra="forbid")


# 실제 서비스에서는 유출된 비밀번호 목록 수십만 개를 씁니다. 여기서는 예시로 몇 개만 둡니다.
COMMON_PASSWORDS = {
    "password1234", "1234567890", "qwerty1234", "qwertyuiop", "iloveyou12",
    "admin12345", "abcd123456", "1q2w3e4r5t", "password12", "welcome123",
}


class UserCreate(InputModel):
    """회원가입에 쓰는 입력 모델"""
    email: EmailStr = Field(examples=["user1@example.com"])
    password: str = Field(min_length=10, max_length=64, examples=["practice-pass-1"])

    @model_validator(mode="after")
    def check_password_rules(self):
        password = self.password.lower()
        email_id = self.email.split("@")[0].lower()
        if password in COMMON_PASSWORDS:
            raise ValueError("너무 흔한 비밀번호입니다.")
        if len(email_id) >= 3 and email_id in password:
            raise ValueError("비밀번호에 이메일 아이디를 넣을 수 없습니다.")
        if len(set(password)) < 4:
            raise ValueError("같은 글자를 반복한 비밀번호는 쓸 수 없습니다.")
        return self


class UserRead(BaseModel):
    """사용자 응답 모델. 비밀번호 해시는 넣지 않습니다."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    email: str
    role: str


class UserSummary(UserRead):
    """목록 화면용 사용자 정보. 이메일은 일부만 보여 줍니다."""

    @field_serializer("email")
    def mask_email_field(self, email: str) -> str:
        return mask_email(email)


class Token(BaseModel):
    """로그인과 재발급 응답. 두 토큰을 함께 돌려줍니다."""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshRequest(InputModel):
    """재발급과 로그아웃 요청 본문"""
    refresh_token: str = Field(min_length=1)


class StudyCreate(InputModel):
    """모임 등록 입력 모델"""
    title: str = Field(min_length=1, max_length=100, examples=["FastAPI 주말 스터디"])
    description: str = Field(default="", max_length=1000, examples=["토요일 오전에 교안을 함께 읽습니다."])
    capacity: int = Field(ge=2, le=50, examples=[6])


class StudyUpdate(InputModel):
    """모임 일부 수정 입력 모델. 모든 항목이 선택입니다."""
    title: str | None = Field(default=None, min_length=1, max_length=100)
    description: str | None = Field(default=None, max_length=1000)
    capacity: int | None = Field(default=None, ge=2, le=50)
    is_open: bool | None = None  # False로 바꾸면 모집을 마감합니다.


class StudyRead(BaseModel):
    """모임 응답 모델"""

    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    description: str
    capacity: int
    member_count: int
    is_open: bool
    owner_id: int
    created_at: datetime


class StudyPage(BaseModel):
    """모임 목록 응답. 현재 페이지의 모임과 전체 개수를 함께 돌려줍니다."""
    items: list[StudyRead]
    total: int
    page: int
    size: int


class MemberRead(BaseModel):
    """참가자 명단의 한 줄. 이메일은 일부만 보여 줍니다."""

    model_config = ConfigDict(from_attributes=True)

    user_id: int
    email: str
    joined_at: datetime

    @field_serializer("email")
    def mask_email_field(self, email: str) -> str:
        return mask_email(email)
