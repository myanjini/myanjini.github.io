from fastapi import APIRouter, Query, status

from app.dependencies import CurrentUserDep, SessionDep
from app.schemas import MemberRead, StudyCreate, StudyPage, StudyRead, StudyUpdate
from app.services import studies as study_service

router = APIRouter(prefix="/studies", tags=["모임"])

NEED_OWNER = {401: {"description": "로그인 필요"}, 403: {"description": "개설자가 아님"},
              404: {"description": "모임을 찾을 수 없음"}}


@router.get("", response_model=StudyPage, summary="모임 목록 조회")
def list_studies(
    db: SessionDep,
    keyword: str | None = Query(default=None, max_length=50, description="제목에 들어간 글자로 검색"),
    page: int = Query(default=1, ge=1, le=1000, description="페이지 번호(1부터)"),
):
    return study_service.list_studies(db, keyword, page)


# /studies/{study_id}보다 먼저 선언해야 "joined"를 모임 번호로 읽으려다 422가 나지 않습니다.
@router.get("/joined", response_model=list[StudyRead], summary="내가 참가한 모임",
            responses={401: {"description": "로그인 필요"}})
def list_joined_studies(db: SessionDep, user: CurrentUserDep):
    return study_service.joined_studies(db, user)


@router.get("/{study_id}", response_model=StudyRead, summary="모임 상세 조회",
            responses={404: {"description": "모임을 찾을 수 없음"}})
def get_study(db: SessionDep, study_id: int):
    return study_service.find_study(db, study_id)


@router.post("", response_model=StudyRead, status_code=status.HTTP_201_CREATED, summary="모임 등록",
             responses={401: {"description": "로그인 필요"}})
def create_study(db: SessionDep, user: CurrentUserDep, study_in: StudyCreate):
    return study_service.create_study(db, user, study_in)


@router.patch("/{study_id}", response_model=StudyRead, summary="모임 일부 수정",
              responses={**NEED_OWNER, 409: {"description": "정원을 지금 인원보다 적게 줄임"}})
def update_study(db: SessionDep, user: CurrentUserDep, study_id: int, study_in: StudyUpdate):
    return study_service.update_study(db, user, study_id, study_in)


@router.delete("/{study_id}", status_code=status.HTTP_204_NO_CONTENT, summary="모임 삭제",
               responses=NEED_OWNER)
def delete_study(db: SessionDep, user: CurrentUserDep, study_id: int):
    study_service.delete_study(db, user, study_id)


@router.post("/{study_id}/members", response_model=StudyRead, status_code=status.HTTP_201_CREATED,
             summary="모임 참가 신청",
             responses={401: {"description": "로그인 필요"}, 404: {"description": "모임을 찾을 수 없음"},
                        409: {"description": "이미 참가, 정원 초과, 모집 마감"}})
def join_study(db: SessionDep, user: CurrentUserDep, study_id: int):
    return study_service.join_study(db, user, study_id)


@router.delete("/{study_id}/members/me", status_code=status.HTTP_204_NO_CONTENT, summary="모임 나가기",
               responses={401: {"description": "로그인 필요"}, 404: {"description": "모임이 없거나 참가하지 않음"},
                          409: {"description": "개설자는 나갈 수 없음"}})
def leave_study(db: SessionDep, user: CurrentUserDep, study_id: int):
    study_service.leave_study(db, user, study_id)


@router.get("/{study_id}/members", response_model=list[MemberRead], summary="참가자 명단(개설자)",
            responses=NEED_OWNER)
def list_members(db: SessionDep, user: CurrentUserDep, study_id: int):
    return study_service.list_members(db, user, study_id)
