"""참가 신청과 정원 테스트"""
import pytest

from app.errors import AppError
from app.models import Study
from app.repositories import studies as study_repo
from tests.helpers import create_study


def test_join_and_leave(client, make_user):
    owner = make_user("owner@example.com")
    member = make_user("member@example.com")
    study = create_study(client, owner)
    response = client.post(f"/studies/{study['id']}/members", headers=member)
    assert response.status_code == 201
    assert response.json()["member_count"] == 2
    assert [s["id"] for s in client.get("/studies/joined", headers=member).json()] == [study["id"]]

    assert client.delete(f"/studies/{study['id']}/members/me", headers=member).status_code == 204
    assert client.get(f"/studies/{study['id']}").json()["member_count"] == 1


def test_cannot_join_twice(client, make_user):
    owner = make_user("owner@example.com")
    member = make_user("member@example.com")
    study = create_study(client, owner)
    client.post(f"/studies/{study['id']}/members", headers=member)
    response = client.post(f"/studies/{study['id']}/members", headers=member)
    assert response.status_code == 409
    assert response.json()["code"] == "ALREADY_JOINED"


def test_cannot_join_full_or_closed_study(client, make_user):
    owner = make_user("owner@example.com")
    first = make_user("first@example.com")
    late = make_user("late@example.com")
    study = create_study(client, owner, capacity=2)  # 개설자 + 1명
    assert client.post(f"/studies/{study['id']}/members", headers=first).status_code == 201
    response = client.post(f"/studies/{study['id']}/members", headers=late)
    assert response.status_code == 409 and response.json()["message"] == "정원이 모두 찼습니다."

    other = create_study(client, owner)
    client.patch(f"/studies/{other['id']}", json={"is_open": False}, headers=owner)
    response = client.post(f"/studies/{other['id']}/members", headers=late)
    assert response.status_code == 409 and response.json()["message"] == "모집이 마감된 모임입니다."


def test_capacity_cannot_be_less_than_members(client, make_user):
    owner = make_user("owner@example.com")
    study = create_study(client, owner, capacity=3)
    for email in ("m1@example.com", "m2@example.com"):
        client.post(f"/studies/{study['id']}/members", headers=make_user(email))  # 3명이 됩니다.
    response = client.patch(f"/studies/{study['id']}", json={"capacity": 2}, headers=owner)
    assert response.status_code == 409
    assert response.json()["code"] == "CAPACITY_TOO_SMALL"
    assert client.patch(f"/studies/{study['id']}", json={"capacity": 4}, headers=owner).status_code == 200


def test_last_seat_cannot_be_taken_twice(client, db_session, make_user):
    """늦게 도착한 요청이 낡은 인원 수를 믿고 자리를 차지하지 못하는지 확인합니다."""
    owner = make_user("owner@example.com")
    first = make_user("first@example.com")
    study = create_study(client, owner, capacity=2)

    stale = db_session.get(Study, study["id"])  # 자리가 1개 남았을 때 읽어 둔 객체
    assert stale.member_count == 1
    assert client.post(f"/studies/{study['id']}/members", headers=first).status_code == 201  # 다른 요청이 먼저 차지

    assert study_repo.increase_member_count(db_session, stale.id) is False  # 조건부 UPDATE가 막습니다.
    db_session.rollback()
    assert client.get(f"/studies/{study['id']}").json()["member_count"] == 2


def test_owner_cannot_leave(client, auth_headers):
    study = create_study(client, auth_headers)
    response = client.delete(f"/studies/{study['id']}/members/me", headers=auth_headers)
    assert response.status_code == 409
