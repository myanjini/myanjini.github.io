"""모임 CRUD와 입력 검증 테스트"""
import pytest

from tests.helpers import create_study


def test_create_and_get_study(client, auth_headers):
    study = create_study(client, auth_headers, title="FastAPI 주말 스터디", capacity=6)
    assert study["member_count"] == 1 and study["is_open"] is True  # 개설자가 첫 참가자
    response = client.get(f"/studies/{study['id']}")
    assert response.status_code == 200
    assert response.json()["title"] == "FastAPI 주말 스터디"


def test_search_by_keyword(client, auth_headers):
    create_study(client, auth_headers, title="FastAPI 스터디")
    create_study(client, auth_headers, title="알고리즘 모임")
    body = client.get("/studies", params={"keyword": "FastAPI"}).json()
    assert body["total"] == 1
    assert body["items"][0]["title"] == "FastAPI 스터디"


def test_create_without_login_is_401(client):
    response = client.post("/studies", json={"title": "x", "capacity": 3})
    assert response.status_code == 401


@pytest.mark.parametrize("data", [
    {"title": "", "capacity": 3},                        # 빈 제목
    {"title": "x" * 101, "capacity": 3},                 # 너무 긴 제목
    {"title": "x", "capacity": 1},                       # 정원 범위 밖
    {"title": "x", "capacity": 51},
    {"title": "x", "capacity": 3, "owner_id": 999},      # 정의하지 않은 필드(남을 개설자로 지정 시도)
    {"title": "x", "capacity": 3, "member_count": 0},
])
def test_invalid_study_is_422(client, auth_headers, data):
    response = client.post("/studies", json=data, headers=auth_headers)
    assert response.status_code == 422


def test_invalid_page_is_422(client):
    assert client.get("/studies", params={"page": 0}).status_code == 422
