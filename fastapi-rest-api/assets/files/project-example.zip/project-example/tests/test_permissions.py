"""권한 테스트: 개설자만 수정, 삭제, 명단 조회"""
from tests.helpers import create_study


def test_other_user_cannot_update_study(client, make_user):
    owner = make_user("owner@example.com")
    other = make_user("other@example.com")
    study = create_study(client, owner)
    response = client.patch(f"/studies/{study['id']}", json={"title": "바꿔 버림"}, headers=other)
    assert response.status_code == 403
    assert client.get(f"/studies/{study['id']}").json()["title"] == "테스트 모임"  # 바뀌지 않았는지 확인


def test_other_user_cannot_delete_study(client, make_user):
    owner = make_user("owner@example.com")
    other = make_user("other@example.com")
    study = create_study(client, owner)
    assert client.delete(f"/studies/{study['id']}", headers=other).status_code == 403
    assert client.delete(f"/studies/{study['id']}", headers=owner).status_code == 204
    assert client.get(f"/studies/{study['id']}").status_code == 404


def test_admin_can_delete_any_study(client, make_user):
    owner = make_user("owner@example.com")
    admin = make_user("admin@example.com", role="admin")
    study = create_study(client, owner)
    assert client.delete(f"/studies/{study['id']}", headers=admin).status_code == 204


def test_members_list_is_owner_only_and_masked(client, make_user):
    owner = make_user("owner@example.com")
    member = make_user("member@example.com")
    study = create_study(client, owner)
    client.post(f"/studies/{study['id']}/members", headers=member)

    assert client.get(f"/studies/{study['id']}/members", headers=member).status_code == 403
    response = client.get(f"/studies/{study['id']}/members", headers=owner)
    assert response.status_code == 200
    emails = [m["email"] for m in response.json()]
    assert emails == ["ow***@example.com", "me***@example.com"]  # 전체 이메일은 보이지 않습니다.
