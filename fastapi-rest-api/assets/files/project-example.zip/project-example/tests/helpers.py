"""여러 테스트에서 함께 쓰는 도우미 함수"""


def create_study(client, headers: dict, **fields) -> dict:
    """테스트에 쓸 모임을 등록하고 응답 본문을 돌려줍니다."""
    data = {"title": "테스트 모임", "capacity": 3} | fields
    response = client.post("/studies", json=data, headers=headers)
    assert response.status_code == 201
    return response.json()
