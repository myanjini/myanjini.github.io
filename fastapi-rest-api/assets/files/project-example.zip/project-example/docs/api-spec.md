# API 명세서: 스터디 모임 API

- 한 문장 소개: 회원이 스터디 모임을 열고, 다른 회원이 정원 안에서 참가 신청을 하는 API입니다.

## 자원과 관계

| 자원 | 주요 필드와 규칙 | 소유자 | 관계 |
|---|---|---|---|
| User | email, password(해시), role | 본인 | 템플릿 제공 |
| Study | title(1~100자), description(최대 1000자), capacity(2~50, 개설자 포함), member_count, is_open | 개설자(owner_id) | User 1:N |
| Membership | study_id, user_id, joined_at. 한 사람은 한 모임에 한 번만 | 참가한 회원 | Study N:1, User N:1 |

## API 목록

| 기능 | 메서드 | URI | 요청 본문과 검증 규칙 | 응답 | 상태 코드 | 인증/권한 |
|---|---|---|---|---|---|---|
| 회원가입 | POST | /auth/signup | email(이메일 형식), password(10~64자, 흔한 비밀번호 금지) | UserRead | 201, 409, 422 | 없음 |
| 로그인 | POST | /auth/token | username(이메일), password(폼) | Token | 200, 401, 429 | 없음 |
| 모임 목록 | GET | /studies?keyword=&page= | keyword(최대 50자), page(1~1000) | StudyPage | 200, 422 | 없음 |
| 모임 상세 | GET | /studies/{study_id} | 없음 | StudyRead | 200, 404 | 없음 |
| 모임 등록 | POST | /studies | title(1~100자), description(최대 1000자), capacity(2~50), 그 밖의 필드 금지 | StudyRead | 201, 401, 422 | 로그인 사용자 |
| 모임 수정 | PATCH | /studies/{study_id} | title, description, capacity, is_open(모두 선택, 규칙은 등록과 같음) | StudyRead | 200, 401, 403, 404, 409, 422 | 개설자 본인, 관리자 |
| 모임 삭제 | DELETE | /studies/{study_id} | 없음 | 없음 | 204, 401, 403, 404 | 개설자 본인, 관리자 |
| 참가 신청 | POST | /studies/{study_id}/members | 없음 | StudyRead | 201, 401, 404, 409 | 로그인 사용자 |
| 모임 나가기 | DELETE | /studies/{study_id}/members/me | 없음 | 없음 | 204, 401, 404, 409 | 참가자 본인 |
| 참가자 명단 | GET | /studies/{study_id}/members | 없음 | MemberRead 목록(이메일 가림) | 200, 401, 403, 404 | 개설자 본인, 관리자 |
| 내가 참가한 모임 | GET | /studies/joined | 없음 | StudyRead 목록 | 200, 401 | 로그인 사용자 |

## 권한 표

| 기능 | 로그인 안 함 | 로그인 사용자 | 개설자 본인 | 관리자 |
|---|---|---|---|---|
| 모임 목록, 상세 | O | O | O | O |
| 모임 등록 | 401 | O | O | O |
| 모임 수정, 삭제 | 401 | 403 | O | O |
| 참가 신청 | 401 | O | 409(이미 참가) | O |
| 참가자 명단 | 401 | 403 | O | O |

## 주요 위협과 보안 요구사항

| 번호 | 위협 | 관련 항목 | 보안 요구사항 | 확인 테스트 |
|---|---|---|---|---|
| 1 | 남의 모임을 수정, 삭제 | 부적절한 인가, OWASP API1 | 개설자와 관리자만 수정, 삭제(그 밖은 403) | test_other_user_cannot_update_study, test_other_user_cannot_delete_study |
| 2 | 참가자 이메일 수집 | 개인정보 노출, OWASP API3 | 명단은 개설자만 보고, 이메일은 앞 두 글자와 도메인만 | test_members_list_is_owner_only_and_masked |
| 3 | 마지막 자리를 동시에 여러 명이 신청 | 경쟁 조건 | 조건부 UPDATE로 인원 증가, 실패하면 409. 같은 사람 중복은 유일 제약 | test_last_seat_cannot_be_taken_twice, test_cannot_join_twice |
| 4 | 요청 본문에 owner_id, member_count를 넣어 조작 | 입력데이터 검증, OWASP API3 | 정의하지 않은 필드는 422 | test_invalid_study_is_422 |
| 5 | 비밀번호 무차별 대입 | 반복된 인증시도 제한 기능 부재 | 15분에 5번 실패하면 429(템플릿 제공) | test_login_is_locked_after_five_failures |

## 범위에서 뺀 것

모임 일정, 댓글, 출석 확인, 화면
