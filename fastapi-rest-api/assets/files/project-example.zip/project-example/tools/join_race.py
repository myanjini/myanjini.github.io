"""동시 참가 시험: 한 모임에 10명이 동시에 참가 신청을 보냅니다. 사용법: python tools/join_race.py 모임번호"""
import sys
from concurrent.futures import ThreadPoolExecutor

import httpx

BASE_URL = "http://127.0.0.1:8000"
STUDY_ID = int(sys.argv[1])
PASSWORD = "race-test-pass-1"


def login(i: int) -> dict:
    email = f"race{i}@example.com"
    httpx.post(f"{BASE_URL}/auth/signup", json={"email": email, "password": PASSWORD})  # 이미 있으면 409, 무시
    token = httpx.post(f"{BASE_URL}/auth/token", data={"username": email, "password": PASSWORD}).json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def join(headers: dict) -> int:
    return httpx.post(f"{BASE_URL}/studies/{STUDY_ID}/members", headers=headers, timeout=30).status_code


users = [login(i) for i in range(10)]           # 먼저 10명이 모두 로그인해 둡니다.
with ThreadPoolExecutor(max_workers=10) as pool:  # 10개의 요청을 한꺼번에 보냅니다.
    results = list(pool.map(join, users))

print("상태 코드:", sorted(results))
print("최종 인원:", httpx.get(f"{BASE_URL}/studies/{STUDY_ID}").json()["member_count"])
