#!/usr/bin/env bash
# 발표 시연 스크립트: 로그인부터 막히는 장면까지 순서대로 보여 줍니다.
# 사용법: BASE=http://ALB주소 bash tools/demo.sh
set -u
BASE=${BASE:-http://localhost:8000}
PW=demo-pass-2026
RUN=$(date +%s)  # 시연할 때마다 새 계정을 쓰려고 붙이는 번호

step() { printf '\n== %s\n' "$1"; }
signup_login() {
  curl -s -o /dev/null -X POST "$BASE/auth/signup" -H "Content-Type: application/json" -d "{\"email\":\"$1\",\"password\":\"$PW\"}"
  curl -s -X POST "$BASE/auth/token" -d "username=$1&password=$PW" | python3 -c "import sys,json;print(json.load(sys.stdin)['access_token'])"
}

step "1. 서버 상태"
curl -s "$BASE/health"; echo

step "2. 개설자, 참가자, 늦게 온 사람 로그인"
OWNER=$(signup_login "owner$RUN@example.com")
MEMBER=$(signup_login "member$RUN@example.com")
LATE=$(signup_login "late$RUN@example.com")
echo "토큰 세 개를 받았습니다."

step "3. 개설자가 정원 2명(개설자 포함) 모임 등록"
STUDY=$(curl -s -X POST "$BASE/studies" -H "Authorization: Bearer $OWNER" -H "Content-Type: application/json" \
  -d '{"title":"시연용 FastAPI 스터디","capacity":2}')
echo "$STUDY"
ID=$(echo "$STUDY" | python3 -c "import sys,json;print(json.load(sys.stdin)['id'])")

step "4. 참가자가 신청(201), 늦은 사람은 정원 초과(409)"
curl -s -o /dev/null -w "%{http_code}\n" -X POST "$BASE/studies/$ID/members" -H "Authorization: Bearer $MEMBER"
curl -s -X POST "$BASE/studies/$ID/members" -H "Authorization: Bearer $LATE"; echo

step "5. 참가자가 남의 모임 수정 시도(403)"
curl -s -X PATCH "$BASE/studies/$ID" -H "Authorization: Bearer $MEMBER" -H "Content-Type: application/json" -d '{"title":"바꿔 버림"}'; echo

step "6. 토큰 없이 등록 시도(401)"
curl -s -X POST "$BASE/studies" -H "Content-Type: application/json" -d '{"title":"x","capacity":3}'; echo

step "7. 개설자만 보는 명단(이메일 가림)"
curl -s "$BASE/studies/$ID/members" -H "Authorization: Bearer $OWNER"; echo
