# 스터디 모임 API

회원이 스터디 모임을 열고, 다른 회원이 정원 안에서 참가 신청을 하는 API입니다. 9일차 미니 프로젝트의 예시이며, 시작 템플릿(project-starter)에 S17의 코드를 더한 완성본입니다.

## 실행 방법

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env               # SECRET_KEY를 새로 만들어 채웁니다.
alembic upgrade head
uvicorn app.main:app --reload      # http://localhost:8000/docs
pytest -q                          # 28개 통과
```

PostgreSQL로 실행하려면 `.env`의 `POSTGRES_PASSWORD`를 채우고 다음을 실행합니다.

```bash
docker compose up -d --build
docker compose run --rm api alembic upgrade head
python tools/join_race.py 1        # 1번 모임에 10명이 동시에 참가 신청
```

## 발표 시연

```bash
BASE=http://ALB주소 bash tools/demo.sh
```

로그인, 모임 등록, 참가 신청, 정원 초과(409), 남의 모임 수정(403), 토큰 없는 요청(401), 이메일을 가린 명단을 차례로 보여 줍니다.

## API 목록

[docs/api-spec.md](docs/api-spec.md)를 봅니다.

## 보안 조치 요약

| 위협 | 조치 | 테스트 |
|---|---|---|
| 남의 모임 수정, 삭제 | 서비스에서 개설자 검사(403) | tests/test_permissions.py |
| 참가자 이메일 수집 | 명단은 개설자만, 이메일 가림 | tests/test_permissions.py |
| 정원 초과(동시 신청) | 조건부 UPDATE, 유일 제약 | tests/test_members.py |
| 소유자 필드 조작 | 정의하지 않은 필드 422 | tests/test_studies.py |
| 비밀번호 무차별 대입 | 15분에 5번 실패하면 429 | tests/test_auth.py |

## 배포

S18-P61의 순서를 따릅니다.
